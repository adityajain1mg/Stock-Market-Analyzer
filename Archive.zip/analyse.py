from sanic import Blueprint, json
from sanic.response import text
from sanic_ext import render

from managers.stocks import read_stock, add_stock, remove_stock, update_preferences, get_preferences
from managers.analyse import analysis_manager

analyse = Blueprint('analyse', version=1, url_prefix="/analyse")


@analyse.get("/")
async def show(request):
    return text("Analyse Blueprint Root")


@analyse.get("/home")
async def home(request):
    return await render("home.html")


@analyse.get("/historical-analysis")
async def historical_analysis_get(request):
    return await render("historical.html")


@analyse.post("/historical-analysis")
async def historical_analysis_post(request):
    stock = request.form.get("stock_name")
    stock = stock.strip()
    return await analysis_manager(request, [stock], "historical_data.html")


@analyse.get("/compare")
async def compare_get(request):
    return await render("compare.html")


@analyse.post("/compare")
async def compare_post(request):
    stock1 = request.form.get("stock_name_1")
    stock2 = request.form.get("stock_name_2")
    stock1 = stock1.strip()
    stock2 = stock2.strip()
    stock_list = [stock1, stock2]
    print(stock_list)
    if len(stock_list) != 2:
        return text("Invalid format of stocks passed. Please pass <stock_1>&<stock_2> after 'compare' route.")

    return await analysis_manager(request, stock_list, "compare_data.html")


@analyse.get("/real-time")
async def real_time(request):
    return await render(
        "real_time.html", status=200
    )


@analyse.post("/real-time")
async def real_time_post(request):
    stock = request.form.get("stock_name")
    stock = stock.strip()
    return await render(
        "real_time_data.html", context={"data": {"stock": stock}}, status=200
    )
